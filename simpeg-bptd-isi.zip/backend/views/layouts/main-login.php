<?php

use yii\bootstrap\ActiveForm;

//echo $content;
?>
<style>
.form-group{
    margin-bottom: 2px;
}
</style>
<div class="account-pages"></div>
<div class="clearfix"></div>
<div class="wrapper-page">
    <div class=" card-box">
        <div class="panel-heading"> 
            <h3 class="text-center"><strong class="text-custom">Sistem Kepegawaian</strong><br>Balai Pengelola Transportasi Darat Wilayah IV. <br>Riau - Kepri </h3>
        </div> 
        <div class="panel-body">

            <?= $content ?>
               
        </div>   
    </div>
</div>