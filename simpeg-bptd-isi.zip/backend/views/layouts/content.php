<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Isi content -->
            <?= $content ?>

        </div> 
        <!-- container -->
    </div> 
    <!-- content -->

    <footer class="footer">
    © 2016. All rights reserved.
    </footer>
</div>